package com.example.sleepintrain;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.example.sleepintrain.data.DBHelper;

import org.w3c.dom.Text;

public class Service extends AppCompatActivity {

    TextView time;
    Spinner type;
    String type_;
    DBHelper dbHelper;
    String selection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);
        time = findViewById(R.id.id);
        type = findViewById(R.id.spinner);
        setupSpinner();
        ImageView imageView = findViewById(R.id.pic);
        imageView.setImageResource(R.drawable.map);

    }
    private void setupSpinner() {

        ArrayAdapter genderSpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_station, android.R.layout.simple_spinner_item);

        genderSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        type.setAdapter(genderSpinnerAdapter);
        type.setSelection(2);

        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection))
                {
                   type_ = "";
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                type_ = "Электрозаводская";
            }
        }
        );


    }
    boolean check  (String s)
    {
        return s.equals(selection);
    }
    public void save(View v)
    {
        Log.w("Spinner",selection);

        dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] info = {"station","time_1","time_2"};
        String product = "";

        Cursor cursor = db.query("TRAIN_TIME",info,null,null,null,null,null);
        try {

            int stationColumnIndex = cursor.getColumnIndex("station");
            int time_1_ColumnIndex = cursor.getColumnIndex("time_1");
            int time_2_ColumnIndex = cursor.getColumnIndex("time_2");
            while (cursor.moveToNext()) {
                String st = cursor.getString(stationColumnIndex);
                String time1 = cursor.getString(time_1_ColumnIndex);
                String time2 = cursor.getString(time_2_ColumnIndex);
                Log.w("SQLite", type_ + "/"+st+"/"+time1 +"/"+time2);
                if(check(st))
                {
                    product += time1+" "+time2;
                }
            }
            time.setText(product);

        } finally {
            cursor.close();
        }

    }

    public void buy (View view){
        Intent B = new Intent(this, Buy.class);
        startActivity(B);

    }
}
