package com.example.sleepintrain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Buy extends AppCompatActivity {
    EditText num, date, cvv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);
        num = findViewById(R.id.number);
        date = findViewById(R.id.date);
        cvv = findViewById(R.id.cvv);
    }

    boolean check_1 (String S){
        char [] s = S.toCharArray();
        boolean fl = true;
        for (int i = 0; i<S.length(); i++) {
            if (s [i] >= '9' && s[i]<='0' && S.length()==12) fl = false;
        }
        return  fl;
    }

    boolean check_2 (String S){
        char [] s = S.toCharArray();
        boolean fl = true;
        for (int i = 0; i<S.length(); i++) {
            if (s [i] >= '9' && s[i]<='0'&& S.length()==4) fl = false;
        }
        return  fl;
    }

    boolean check_3 (String S){
        char [] s = S.toCharArray();
        boolean fl = true;
        for (int i = 0; i<S.length(); i++) {
            if (s [i] >= '9' && s[i]<='0'&& S.length()==3) fl = false;
        }
        return  fl;
    }

    public void buy_1 (View V){
        String S1 = num.getText().toString();
        String S2 = date.getText().toString();
        String S3 = cvv.getText().toString();
        if (check_1(S1) && !S1.isEmpty() && check_2(S2) && !S2.isEmpty() && check_3(S3) && !S3.isEmpty())
            Toast.makeText(this, "Оплата прошла успешно", Toast.LENGTH_SHORT).show();
        else Toast.makeText(this, "Оплата не прошла", Toast.LENGTH_SHORT).show();
    }
    public void buy_2 (View V){
        String S1 = num.getText().toString();
        String S2 = date.getText().toString();
        String S3 = cvv.getText().toString();
        if (check_1(S1) && !S1.isEmpty() && check_2(S2) && !S2.isEmpty() && check_3(S3) && !S3.isEmpty())
            Toast.makeText(this, "Оплата прошла успешно", Toast.LENGTH_SHORT).show();
        else Toast.makeText(this, "Оплата не прошла", Toast.LENGTH_SHORT).show();
    }
}
