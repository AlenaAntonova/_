package com.example.sleepintrain;



import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private final static String FILE = "enter.txt";
    EditText pass;
    EditText log;
    boolean flag=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log = findViewById(R.id.login);
        pass = findViewById(R.id.pass);
        FileInputStream fin = null;
        String info = "";
        try {
            fin = openFileInput(FILE);
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);
            String text = new String(bytes);
            info = text;

        } catch (IOException ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            try {
                if (fin != null)
                    fin.close();
            } catch (IOException ex) {
                Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }
        if (info.isEmpty()) {
            Toast first = Toast.makeText
                    (this,
                            "Привет, зарегистрируйся, чтобы пользоваться приложением",
                            Toast.LENGTH_LONG);
            first.show();

        }
        else
        {
            flag = true;
            char[] avto = info.toCharArray();
            String info_="";
            int m=0;
            for(int i=0;i<info.length();i++)
            {
                if(avto[i]!='\n')
                    info_+=avto[i];
                else
                {
                    if(m==0)
                    {
                        log.setText(info);
                        info_="";
                    }m++;
                }
            }
            String pass_="";
            for(int i=0;i<info_.length();i++)
            {
                pass_+='*';
            }
            pass.setText(pass_);
        }
    }

    public void log(View v)
    {
        String log_ = log.getText().toString();
        String pass_ = pass.getText().toString();
        FileOutputStream fos = null;
        String info = log_ + "\n" +
                pass_;
        try {
            fos = openFileOutput(FILE, MODE_PRIVATE);
            if(!flag)
            {
                Toast.makeText(this, "Данные сохранены", Toast.LENGTH_SHORT).show();
                fos.write(info.getBytes());
            }
            else
                Toast.makeText(this,"Вы успешно вошли",Toast.LENGTH_SHORT).show();
        } catch (IOException ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            try {
                if (fos != null)
                    fos.close();
            } catch (IOException ex) {
                Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        Intent intent = new Intent(this, Service.class);
        startActivity(intent);
    }

}
